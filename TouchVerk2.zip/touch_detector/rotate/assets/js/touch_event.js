const rotateElement = document.getElementById('rotate-element')
let initialAngle = null;
let lastRotation = 0;
let rotateValue = 0;

function setupRotationListener(element) {
    element.addEventListener('touchstart', handleTouchStartRotate, false);
    element.addEventListener('touchmove', handleTouchMoveRotate, false);
    element.addEventListener('touchend', handleTouchEndRotate, false);
}

function handleTouchStartRotate(event) {
    if (event.touches.length == 2) {
        // Initial touch positions
        const touch1 = { x: event.touches[0].pageX, y: event.touches[0].pageY };
        const touch2 = { x: event.touches[1].pageX, y: event.touches[1].pageY };
        // Calculate initial angle
        initialAngle = calculateAngle(touch1, touch2);
    }
}

function handleTouchMoveRotate(event) {
    if (event.touches.length == 2) {
        const touch1 = { x: event.touches[0].pageX, y: event.touches[0].pageY };
        const touch2 = { x: event.touches[1].pageX, y: event.touches[1].pageY };
        const currentAngle = calculateAngle(touch1, touch2);

        if (initialAngle !== null) {
            const rotation = currentAngle - initialAngle;
            const rotationDelta = rotation - lastRotation;
            rotateValue += rotationDelta;
            console.log(`Rotation: ${rotation.toFixed(2)}°, Rotation Delta: ${rotationDelta.toFixed(2)}°`);
            createAlert(`Rotation: ${rotation.toFixed(2)}°, Rotation Delta: ${rotationDelta.toFixed(2)}°`)
            rotateElement.style.transform = `rotate(${rotateValue}deg)`;
            lastRotation = rotation;

        }
    }
}

function handleTouchEndRotate(event) {
    if (event.touches.length < 2) {
        initialAngle = null; // Reset initial angle
        lastRotation = 0;    // Reset last rotation
    }
}

function calculateAngle(touch1, touch2) {
    const dx = touch2.x - touch1.x;
    const dy = touch2.y - touch1.y;
    return Math.atan2(dy, dx) * 180 / Math.PI; // Convert radian to degree
}

// Example usage
setupRotationListener(rotateElement);

const alertarea = document.getElementById('alert-area');

function createAlert(message) {
    const alertString = `
<div class="alert">
  <span class="closebtn" onclick="this.parentElement.style.display='none';">&times;</span> 
  <strong>${message}</strong>
</div>
`
    const parser = new DOMParser();
    const doc = parser.parseFromString(alertString, 'text/html');
    alertarea.appendChild(doc.body);
    setTimeout(function () {
        if(alertarea.childNodes.length > 0){
            alertarea.removeChild(alertarea.childNodes[0]);
        }
    }, 3000); // Alert message duration (e.g., 3000ms or 3 seconds)
}