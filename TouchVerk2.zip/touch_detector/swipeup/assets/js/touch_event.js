const swipupELement = document.getElementById('swipe-element')
function detectSwipeUp(element) {
    let startY = 0;
    element.addEventListener('touchstart', function (e) {
        startY = e.touches[0].clientY;
    }, false);

    element.addEventListener('touchend', function (e) {
        const endY = e.changedTouches[0].clientY;
        if (startY - endY > 100) { // Swipe up distance threshold (e.g., 100 pixels)
            console.log('Swipe Up detected');
            swipupELement.classList.add('swipe-up-animate');
            setTimeout(function () {
                swipupELement.classList.remove('swipe-up-animate');
            }, 300);
            // Trigger your swipe up action here
        }
    }, false);
}
detectSwipeUp(swipupELement);
