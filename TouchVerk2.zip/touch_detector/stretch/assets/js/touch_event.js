
let initialDistance = 0;
let lastDistance = 0;

function setupStretchListener(element) {
    element.addEventListener('touchstart', handleTouchStartStretch, false);
    element.addEventListener('touchmove', handleTouchMoveStretch, false);
    element.addEventListener('touchend', handleTouchEndStretch, false);
}

function handleTouchStartStretch(event) {
    if (event.touches.length == 2) {
        // When two fingers touch the screen, calculate the initial distance between them
        initialDistance = calculateDistance(event.touches[0], event.touches[1]);
        lastDistance = initialDistance;
    }
}

function handleTouchMoveStretch(event) {
    if (event.touches.length == 2) {
        // Calculate the current distance between the two fingers
        const currentDistance = calculateDistanceStretch(event.touches[0], event.touches[1]);

        if (initialDistance !== 0) {
            // Calculate stretch amount relative to the initial distance
            const stretchAmount = currentDistance - initialDistance;
            // Calculate the stretch delta from the last distance
            const stretchDelta = currentDistance - lastDistance;
            console.log(`Stretch Amount: ${stretchAmount.toFixed(2)}, Stretch Delta: ${stretchDelta.toFixed(2)}`);
            createAlert(`Stretch Amount: ${stretchAmount.toFixed(2)}, Stretch Delta: ${stretchDelta.toFixed(2)}`)
            lastDistance = currentDistance;
        }
    }
}

function handleTouchEndStretch(event) {
    if (event.touches.length < 2) {
        initialDistance = 0; // Reset initial distance
        lastDistance = 0;    // Reset last distance
    }
}

function calculateDistanceStretch(touch1, touch2) {
    const dx = touch2.pageX - touch1.pageX;
    const dy = touch2.pageY - touch1.pageY;
    return Math.sqrt(dx * dx + dy * dy);
}

// Example usage
const myElement3 = document.getElementById('myElement3');
setupStretchListener(document.getElementById('stretch-element'));

const alertarea = document.getElementById('alert-area');

function createAlert(message) {
    const alertString = `
<div class="alert">
  <span class="closebtn" onclick="this.parentElement.style.display='none';">&times;</span> 
  <strong>${message}</strong>
</div>
`
    const parser = new DOMParser();
    const doc = parser.parseFromString(alertString, 'text/html');
    alertarea.appendChild(doc.body);
    setTimeout(function () {
        if(alertarea.childNodes.length > 0){
            alertarea.removeChild(alertarea.childNodes[0]);
        }
    }, 3000); // Alert message duration (e.g., 3000ms or 3 seconds)
}