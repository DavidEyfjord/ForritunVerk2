const tapElement =  document.getElementById('tap-element')
function detectTap(element) {
    let startTouchTime = 0;
    element.addEventListener('touchstart', function (e) {
        startTouchTime = Date.now();
    }, false);

    element.addEventListener('touchend', function (e) {
        const endTouchTime = Date.now();
        if (endTouchTime - startTouchTime < 500) { // Tap time threshold (e.g., 500ms)
            console.log('Tap detected');
            tapElement.classList.add('scale-animate');
            setTimeout(function () {
                tapElement.classList.remove('scale-animate');
            }, 300);
            // Trigger your tap action here
        }
    }, false);
}
detectTap(tapElement);
