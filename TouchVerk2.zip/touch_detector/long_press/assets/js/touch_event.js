const longPressElement = document.getElementById('longpress-element')
function detectLongPress(element) {
    let pressTimer = null;
    element.addEventListener('touchstart', function (e) {
        // Clear the timer in case of a repeated touchstart event
        clearTimeout(pressTimer);
        pressTimer = setTimeout(function () {
            console.log('Long Press detected');
            longPressElement.classList.add('long-press-animate');
            setTimeout(function () {
                longPressElement.classList.remove('long-press-animate');
            }, 600);
            // Trigger your long press action here
        }, 2000); // Long press time threshold (e.g., 2000ms or 2 seconds)
    }, false);

    element.addEventListener('touchend', function (e) {
        // Clear the timer to prevent the long press action if touchend event is triggered before 2 seconds
        clearTimeout(pressTimer);
    }, false);
}
detectLongPress(longPressElement);
